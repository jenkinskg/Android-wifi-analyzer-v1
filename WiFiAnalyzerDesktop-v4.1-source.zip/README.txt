Wi-Fi Analyzer v4.1 Desktop
===========================

Based on the v3.1 analyzer interface, now packaged for Windows and Debian.

Features
--------
- Select which installed Wi-Fi adapters are used for scans
- USE ALL / USE NONE / APPLY ADAPTERS / REFRESH ADAPTERS controls
- Adapter choice is saved on the computer
- Top 5 strongest access points
- Line / bar graph switch
- Signal history graph
- ALL / 2.4 GHz / 5 GHz / 6 GHz display filters
- Logs each newly discovered MAC/BSSID once
- Download/share MAC log

Windows
-------
Run the prebuilt WiFiAnalyzer-v4.1.exe. Python is not required on the PC.
The analyzer uses Windows WLAN/netsh and opens its dashboard in the default browser.

Debian
------
Install:
  sudo apt install ./WiFiAnalyzer-v4.1-Debian.deb

Run from the application menu as "Wi-Fi Analyzer v4.1", or:
  wifi-analyzer

Data/log locations
------------------
Windows:
  %LOCALAPPDATA%\WiFiAnalyzer\all_found_macs_v4_1.txt
  %LOCALAPPDATA%\WiFiAnalyzer\adapter_selection_v4_1.json

Debian/Linux:
  ~/.local/share/wifi-analyzer/all_found_macs_v4_1.txt
  ~/.local/share/wifi-analyzer/adapter_selection_v4_1.json

Notes
-----
The adapter controls determine which Wi-Fi adapters the program queries.
The band buttons are display filters. Windows/NetworkManager controls which
bands and access points each Wi-Fi adapter can actually scan.
