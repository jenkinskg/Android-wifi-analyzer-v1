#!/bin/sh
set -eu
ROOT="$(pwd)/debian-root"
OUT="$(pwd)/WiFiAnalyzer-v4.1-Debian.deb"
rm -rf "$ROOT"
mkdir -p "$ROOT/DEBIAN" "$ROOT/usr/lib/wifi-analyzer" "$ROOT/usr/bin" "$ROOT/usr/share/applications" "$ROOT/usr/share/icons/hicolor/scalable/apps"
cp wifi_analyzer_v4_1.py "$ROOT/usr/lib/wifi-analyzer/wifi_analyzer_v4_1.py"
chmod 755 "$ROOT/usr/lib/wifi-analyzer/wifi_analyzer_v4_1.py"
cat > "$ROOT/usr/bin/wifi-analyzer" <<'EOS'
#!/bin/sh
exec /usr/bin/python3 /usr/lib/wifi-analyzer/wifi_analyzer_v4_1.py "$@"
EOS
chmod 755 "$ROOT/usr/bin/wifi-analyzer"
cat > "$ROOT/usr/share/applications/wifi-analyzer.desktop" <<'EOS'
[Desktop Entry]
Type=Application
Name=Wi-Fi Analyzer v4.1
Comment=Desktop Wi-Fi analyzer with adapter selection, band filters, graphs, and MAC/BSSID logging
Exec=wifi-analyzer
Icon=wifi-analyzer
Terminal=false
Categories=Network;Utility;
Keywords=wifi;wireless;network;analyzer;ssid;bssid;
EOS
cat > "$ROOT/usr/share/icons/hicolor/scalable/apps/wifi-analyzer.svg" <<'EOS'
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
 <rect x="4" y="4" width="120" height="120" rx="24" fill="#101d2e"/>
 <path d="M22 49c25-22 59-22 84 0M35 65c17-15 41-15 58 0M49 81c9-8 21-8 30 0" fill="none" stroke="#36d9ff" stroke-width="9" stroke-linecap="round"/>
 <circle cx="64" cy="98" r="7" fill="#43e18b"/>
</svg>
EOS
cat > "$ROOT/DEBIAN/control" <<'EOS'
Package: wifi-analyzer-desktop
Version: 4.1.0
Section: net
Priority: optional
Architecture: all
Depends: python3, network-manager, xdg-utils
Maintainer: Wi-Fi Analyzer Project
Description: Wi-Fi Analyzer v4.1 Desktop
 Desktop Wi-Fi analyzer based on the v3.1 interface. Shows strongest
 access points, selectable Wi-Fi adapters, line/bar signal graphs,
 2.4/5/6 GHz display filters, signal history, and a de-duplicated
 MAC/BSSID log. Uses NetworkManager nmcli on Debian/Linux.
EOS
cat > "$ROOT/DEBIAN/postinst" <<'EOS'
#!/bin/sh
set -e
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database /usr/share/applications >/dev/null 2>&1 || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q /usr/share/icons/hicolor >/dev/null 2>&1 || true
exit 0
EOS
chmod 755 "$ROOT/DEBIAN/postinst"
chmod g-s "$ROOT/DEBIAN" 2>/dev/null || true
dpkg-deb --build --root-owner-group "$ROOT" "$OUT"
echo "Built: $OUT"
