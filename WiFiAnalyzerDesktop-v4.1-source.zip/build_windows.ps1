$ErrorActionPreference = 'Stop'
python -m pip install --upgrade pip pyinstaller
python -m PyInstaller --clean --noconfirm --onefile --windowed --name WiFiAnalyzer-v4.1 wifi_analyzer_v4_1.py
Write-Host "Built: dist\WiFiAnalyzer-v4.1.exe"
