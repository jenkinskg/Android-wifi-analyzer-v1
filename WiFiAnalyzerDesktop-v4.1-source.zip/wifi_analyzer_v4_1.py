#!/usr/bin/env python3
# Wi-Fi Analyzer v4.1 Desktop
# Based on the v3.1 Android/Termux dashboard. Supports Windows and Debian/Linux.

import json
import os
import platform
import re
import signal
import subprocess
import sys
import threading
import time
import webbrowser
from collections import defaultdict, deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

HOST = "127.0.0.1"
PORT = int(os.environ.get("WIFI_ANALYZER_PORT", "8080"))
SCAN_INTERVAL = 5.0
HISTORY_POINTS = 60
TOP_COUNT = 5
VERSION = "4.1"

SYSTEM = platform.system().lower()
IS_WINDOWS = SYSTEM == "windows"
IS_LINUX = SYSTEM == "linux"

if IS_WINDOWS:
    _base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    DATA_DIR = Path(_base) / "WiFiAnalyzer"
else:
    DATA_DIR = Path.home() / ".local" / "share" / "wifi-analyzer"
ALL_MAC_LOG = DATA_DIR / "all_found_macs_v4_1.txt"
ADAPTER_CONFIG = DATA_DIR / "adapter_selection_v4_1.json"

state_lock = threading.Lock()
latest_aps = []
history = defaultdict(lambda: deque(maxlen=HISTORY_POINTS))
last_error = ""
last_scan_time = ""
scan_number = 0
running = True
logged_macs = set()
backend_name = "Windows WLAN (netsh)" if IS_WINDOWS else "NetworkManager (nmcli)" if IS_LINUX else "Unsupported OS"
adapter_inventory = []
selected_adapters = set()
adapter_selection_loaded = False


def channel_from_frequency(freq):
    try:
        f = int(freq)
    except Exception:
        return "?"
    if f == 2484:
        return 14
    if 2412 <= f <= 2472:
        return (f - 2407) // 5
    if 5000 <= f <= 5895:
        return (f - 5000) // 5
    if 5955 <= f <= 7115:
        return (f - 5950) // 5
    return "?"


def band_from_frequency(freq):
    try:
        f = int(freq)
    except Exception:
        return "Unknown"
    if 2400 <= f < 2500:
        return "2.4 GHz"
    if 4900 <= f < 5925:
        return "5 GHz"
    if 5925 <= f <= 7125:
        return "6 GHz"
    return "Other"


def frequency_from_channel(channel, band=""):
    try:
        ch = int(channel)
    except Exception:
        return 0
    b = (band or "").lower().replace(" ", "")
    if "6" in b and "ghz" in b:
        if ch == 2:
            return 5935
        return 5950 + 5 * ch
    if "5" in b and "ghz" in b:
        return 5000 + 5 * ch
    if "2.4" in b or "2ghz" in b:
        if ch == 14:
            return 2484
        return 2407 + 5 * ch
    if ch == 14:
        return 2484
    if 1 <= ch <= 13:
        return 2407 + 5 * ch
    if 32 <= ch <= 177:
        return 5000 + 5 * ch
    if 178 <= ch <= 233:
        return 5950 + 5 * ch
    return 0


def normalize_band(raw):
    s = (raw or "").strip().lower()
    if "6" in s and "ghz" in s:
        return "6 GHz"
    if "5" in s and "ghz" in s:
        return "5 GHz"
    if "2.4" in s or "2 ghz" in s or "2ghz" in s:
        return "2.4 GHz"
    return ""


def dedupe_sort(aps):
    unique = {}
    for ap in aps:
        mac = ap.get("mac", "").upper()
        if not mac:
            continue
        ap = dict(ap)
        ap["mac"] = mac
        sources = set(ap.get("adapters") or [])
        if ap.get("adapter"):
            sources.add(ap["adapter"])
        ap["adapters"] = sorted(sources)
        previous = unique.get(mac)
        if previous is None:
            unique[mac] = ap
            continue
        merged_sources = set(previous.get("adapters") or []) | sources
        if ap.get("rssi", -200) > previous.get("rssi", -200):
            ap["adapters"] = sorted(merged_sources)
            unique[mac] = ap
        else:
            previous["adapters"] = sorted(merged_sources)
    return sorted(unique.values(), key=lambda a: a.get("rssi", -200), reverse=True)


def split_nmcli_terse(line):
    parts, buf, escaped = [], [], False
    for ch in line.rstrip("\r\n"):
        if escaped:
            buf.append(ch)
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == ":":
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    if escaped:
        buf.append("\\")
    parts.append("".join(buf))
    return parts



def _load_adapter_selection_file():
    global adapter_selection_loaded, selected_adapters
    if adapter_selection_loaded:
        return
    adapter_selection_loaded = True
    try:
        data = json.loads(ADAPTER_CONFIG.read_text(encoding="utf-8"))
        selected_adapters = {str(x) for x in data.get("selected", []) if str(x)}
    except Exception:
        selected_adapters = set()


def _save_adapter_selection_file():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = ADAPTER_CONFIG.with_suffix(".tmp")
    tmp.write_text(json.dumps({"selected": sorted(selected_adapters)}, indent=2), encoding="utf-8")
    tmp.replace(ADAPTER_CONFIG)


def list_linux_adapters():
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    result = subprocess.run(
        ["nmcli", "-t", "--escape", "yes", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status"],
        capture_output=True, text=True, timeout=15, env=env,
    )
    if result.returncode != 0:
        msg = (result.stderr or result.stdout or "Unable to list NetworkManager devices").strip()
        raise RuntimeError(msg)
    adapters = []
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        parts = split_nmcli_terse(line)
        if len(parts) < 3 or parts[1].strip().lower() != "wifi":
            continue
        name = parts[0].strip()
        state = parts[2].strip()
        connection = parts[3].strip() if len(parts) > 3 else ""
        adapters.append({
            "id": name,
            "name": name,
            "description": connection or "Wi-Fi adapter",
            "state": state,
        })
    return adapters


def list_windows_adapters():
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        ["netsh", "wlan", "show", "interfaces"],
        capture_output=True, text=True, errors="replace", timeout=15,
        creationflags=creationflags,
    )
    if result.returncode != 0:
        msg = (result.stderr or result.stdout or "Unable to list Windows WLAN interfaces").strip()
        raise RuntimeError(msg)
    adapters = []
    current = None
    for raw in result.stdout.splitlines():
        line = raw.strip()
        m = re.match(r"^Name\s*:\s*(.+)$", line, re.I)
        if m:
            if current and current.get("name"):
                adapters.append(current)
            name = m.group(1).strip()
            current = {"id": name, "name": name, "description": "Wi-Fi adapter", "state": "unknown"}
            continue
        if current is None:
            continue
        m = re.match(r"^Description\s*:\s*(.+)$", line, re.I)
        if m:
            current["description"] = m.group(1).strip()
            continue
        m = re.match(r"^State\s*:\s*(.+)$", line, re.I)
        if m:
            current["state"] = m.group(1).strip()
            continue
    if current and current.get("name"):
        adapters.append(current)
    return adapters


def refresh_adapter_inventory():
    global adapter_inventory, selected_adapters
    _load_adapter_selection_file()
    adapters = list_windows_adapters() if IS_WINDOWS else list_linux_adapters() if IS_LINUX else []
    ids = {a["id"] for a in adapters}
    with state_lock:
        first_discovery = not adapter_inventory and not selected_adapters and not ADAPTER_CONFIG.exists()
        adapter_inventory = adapters
        if first_discovery:
            selected_adapters = set(ids)
        else:
            selected_adapters.intersection_update(ids)
        for a in adapter_inventory:
            a["selected"] = a["id"] in selected_adapters
    return adapters


def set_selected_adapters(adapter_ids):
    global selected_adapters
    refresh_adapter_inventory()
    valid = {a["id"] for a in adapter_inventory}
    requested = {str(x) for x in adapter_ids}
    with state_lock:
        selected_adapters = requested & valid
        for a in adapter_inventory:
            a["selected"] = a["id"] in selected_adapters
        _save_adapter_selection_file()
    return sorted(selected_adapters)


def adapter_snapshot():
    try:
        refresh_adapter_inventory()
    except Exception:
        pass
    with state_lock:
        return [dict(a) for a in adapter_inventory]

def scan_linux_nmcli(adapter):
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    cmd = [
        "nmcli", "-t", "--escape", "yes",
        "-f", "SSID,BSSID,SIGNAL,FREQ,CHAN,SECURITY",
        "device", "wifi", "list", "ifname", adapter, "--rescan", "yes",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, env=env)
    if result.returncode != 0:
        msg = (result.stderr or result.stdout or "nmcli Wi-Fi scan failed").strip()
        raise RuntimeError(msg)
    aps = []
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        parts = split_nmcli_terse(line)
        if len(parts) < 6:
            continue
        ssid, bssid, signal_pct, freq, chan, security = parts[:6]
        try:
            pct = max(0, min(100, int(signal_pct)))
            rssi = int(round(pct / 2.0 - 100))
        except Exception:
            rssi = -100
        try:
            f = int(freq)
        except Exception:
            f = 0
        try:
            c = int(chan)
        except Exception:
            c = channel_from_frequency(f)
        if not f and c != "?":
            f = frequency_from_channel(c)
        aps.append({
            "mac": bssid.upper(),
            "ssid": ssid or "<hidden>",
            "rssi": rssi,
            "frequency": f,
            "channel": c,
            "band": band_from_frequency(f),
            "width": "?",
            "security": security or "",
            "adapter": adapter,
            "adapters": [adapter],
        })
    return dedupe_sort(aps)


def scan_windows_netsh(adapter):
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        ["netsh", "wlan", "show", "networks", f"interface={adapter}", "mode=bssid"],
        capture_output=True, text=True, errors="replace", timeout=30,
        creationflags=creationflags,
    )
    if result.returncode != 0:
        msg = (result.stderr or result.stdout or "Windows WLAN scan failed").strip()
        raise RuntimeError(msg)

    aps = []
    current_ssid = "<hidden>"
    auth = ""
    encryption = ""
    current = None

    def finish():
        nonlocal current
        if not current or not current.get("mac"):
            current = None
            return
        band = normalize_band(current.get("band_raw", ""))
        channel = current.get("channel", "?")
        freq = frequency_from_channel(channel, band)
        if not band:
            band = band_from_frequency(freq)
        current["frequency"] = freq
        current["band"] = band or "Unknown"
        current["width"] = "?"
        current["security"] = " / ".join(x for x in [auth, encryption] if x)
        current["adapter"] = adapter
        current["adapters"] = [adapter]
        current.pop("band_raw", None)
        aps.append(current)
        current = None

    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        m = re.match(r"^SSID\s+\d+\s*:\s*(.*)$", line, re.I)
        if m:
            finish()
            current_ssid = m.group(1).strip() or "<hidden>"
            auth = ""
            encryption = ""
            continue
        m = re.match(r"^Authentication\s*:\s*(.*)$", line, re.I)
        if m:
            auth = m.group(1).strip()
            continue
        m = re.match(r"^Encryption\s*:\s*(.*)$", line, re.I)
        if m:
            encryption = m.group(1).strip()
            continue
        m = re.match(r"^BSSID\s+\d+\s*:\s*([0-9A-Fa-f:.-]{11,})", line, re.I)
        if m:
            finish()
            mac = m.group(1).replace("-", ":").upper()
            current = {"mac": mac, "ssid": current_ssid, "rssi": -100, "channel": "?", "band_raw": ""}
            continue
        if current is None:
            continue
        m = re.match(r"^Signal\s*:\s*(\d+)%", line, re.I)
        if m:
            pct = max(0, min(100, int(m.group(1))))
            current["rssi"] = int(round(pct / 2.0 - 100))
            continue
        m = re.match(r"^Channel\s*:\s*(\d+)", line, re.I)
        if m:
            current["channel"] = int(m.group(1))
            continue
        m = re.match(r"^Band\s*:\s*(.*)$", line, re.I)
        if m:
            current["band_raw"] = m.group(1).strip()
            continue
    finish()
    return dedupe_sort(aps)


def scan_wifi():
    refresh_adapter_inventory()
    with state_lock:
        chosen = [a["id"] for a in adapter_inventory if a["id"] in selected_adapters]
    if not chosen:
        raise RuntimeError("No Wi-Fi adapters are selected. Use ADAPTERS to select at least one adapter.")
    all_aps = []
    errors = []
    for adapter in chosen:
        try:
            if IS_WINDOWS:
                all_aps.extend(scan_windows_netsh(adapter))
            elif IS_LINUX:
                all_aps.extend(scan_linux_nmcli(adapter))
        except Exception as exc:
            errors.append(f"{adapter}: {exc}")
    aps = dedupe_sort(all_aps)
    if not aps and errors:
        raise RuntimeError(" | ".join(errors))
    return aps


def print_top_aps(aps):
    global scan_number
    scan_number += 1
    print("\n" + "=" * 78)
    print(f"SCAN #{scan_number}   {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}   APs seen: {len(aps)}")
    print("=" * 78)
    if not aps:
        print("No access points returned.", flush=True)
        return
    print(f"{'#':<3} {'BSSID / MAC':<19} {'RSSI':>7} {'FREQ':>9} {'CH':>4} {'BAND':<8} SSID")
    print("-" * 78)
    for i, ap in enumerate(aps[:TOP_COUNT], 1):
        print(f"{i:<3} {ap['mac']:<19} {ap['rssi']:>5} dBm {ap['frequency']:>5} MHz {str(ap['channel']):>4} {ap['band']:<8} {ap['ssid']}")
    print("-" * 78)
    strongest = aps[0]
    print(f"STRONGEST: {strongest['mac']}   {strongest['rssi']} dBm   {strongest['frequency']} MHz   {strongest['ssid']}")
    print(f"Dashboard: http://{HOST}:{PORT}", flush=True)


def load_logged_macs():
    logged_macs.clear()
    if not ALL_MAC_LOG.exists():
        return
    try:
        with ALL_MAC_LOG.open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("AP\t"):
                    parts = line.rstrip("\n").split("\t")
                    if len(parts) >= 3:
                        logged_macs.add(parts[2].strip().upper())
    except Exception:
        pass


def append_new_mac_log(aps):
    if not aps:
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    new_aps = [ap for ap in aps if ap["mac"] not in logged_macs]
    if not new_aps:
        return
    new_file = not ALL_MAC_LOG.exists() or ALL_MAC_LOG.stat().st_size == 0
    stamp = datetime.now().astimezone().isoformat(timespec="seconds")
    with ALL_MAC_LOG.open("a", encoding="utf-8") as f:
        if new_file:
            f.write("Wi-Fi Analyzer v4.1 Desktop - All Found MAC/BSSID Log\n")
            f.write("Each BSSID is recorded once, when first discovered.\n")
            f.write("TYPE\tFIRST_SEEN\tMAC/BSSID\tSSID\tRSSI_DBM\tFREQUENCY_MHZ\tCHANNEL\tBAND\tWIDTH_MHZ\tSECURITY\n")
        for ap in new_aps:
            security = str(ap.get("security", "")).replace("\t", " ").replace("\n", " ")
            ssid = str(ap.get("ssid", "")).replace("\t", " ").replace("\n", " ")
            f.write("AP\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n".format(
                stamp, ap["mac"], ssid, ap["rssi"], ap["frequency"], ap["channel"], ap["band"], ap.get("width", "?"), security
            ))
            logged_macs.add(ap["mac"])


def scanner_loop():
    global latest_aps, last_error, last_scan_time
    while running:
        cycle_start = time.time()
        try:
            aps = scan_wifi()
            stamp = datetime.now().strftime("%H:%M:%S")
            with state_lock:
                if aps:
                    latest_aps = aps
                    last_error = ""
                    for ap in aps[:20]:
                        history[ap["mac"]].append({"time": stamp, "rssi": ap["rssi"]})
                last_scan_time = stamp
            if aps:
                print_top_aps(aps)
                append_new_mac_log(aps)
            else:
                print(f"[{stamp}] No new APs returned; holding the last good scan.", flush=True)
        except Exception as exc:
            msg = str(exc)
            with state_lock:
                last_error = msg
                last_scan_time = datetime.now().strftime("%H:%M:%S")
            print(f"\nWI-FI SCAN ERROR\n{msg}\n", flush=True)
        elapsed = time.time() - cycle_start
        time.sleep(max(0.5, SCAN_INTERVAL - elapsed))


HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>Wi-Fi Analyzer v4.1 Desktop</title>
<style>
:root{--bg:#07111d;--panel:#101d2e;--line:#29445f;--text:#eff7ff;--muted:#9bb0c8;--cyan:#36d9ff;--green:#43e18b;--yellow:#ffd047;--orange:#ff9851;--red:#ff5d6c;--purple:#b28aff}
*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#07111d,#0a1727);color:var(--text);font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}.wrap{max-width:1200px;margin:auto;padding:10px}header{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap}h1{margin:0;font-size:clamp(25px,6vw,42px)}.small{font-size:13px;color:var(--muted)}.badges{display:flex;gap:8px;flex-wrap:wrap}.badge{background:var(--panel);border:1px solid var(--line);border-radius:999px;padding:8px 12px}.ok{color:var(--green)}.bad{color:var(--red)}.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:13px}.hero{margin:12px 0}.heroMac{font:800 clamp(29px,8vw,60px) ui-monospace,SFMono-Regular,monospace;color:var(--cyan);word-break:break-all}.heroMeta{display:flex;gap:12px;flex-wrap:wrap;color:var(--muted);margin-top:7px}.grid{display:grid;grid-template-columns:1fr 1.25fr;gap:12px}table{width:100%;border-collapse:collapse}th,td{padding:10px 7px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}th{font-size:11px;color:var(--muted);text-transform:uppercase}.mac{font:800 15px ui-monospace,SFMono-Regular,monospace;color:var(--cyan)}.sig{font-weight:900}canvas{display:block;width:100%;background:#091727;border-radius:12px}#currentChart{height:340px}#historyChart{height:300px}button,.actionLink{background:#17304a;color:var(--text);border:1px solid var(--line);border-radius:10px;padding:9px 12px;font-weight:750;text-decoration:none;display:inline-block;margin:6px 5px 6px 0;cursor:pointer}button.active{border-color:var(--cyan);color:var(--cyan)}button.stop{border-color:var(--red);color:var(--red)}.controls{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:6px 0 8px}.error{color:var(--red);font-weight:750;white-space:pre-wrap}@media(max-width:850px){.grid{grid-template-columns:1fr}#currentChart{height:310px}#historyChart{height:280px}}
</style></head><body><div class="wrap">
<header><div><h1>Wi-Fi Analyzer v4.1</h1><div class="small">Desktop edition • based on v3.1 • Windows + Debian/Linux</div></div><div class="badges"><div class="badge" id="platformBadge">Platform: —</div><div class="badge" id="statusBadge">Connecting…</div><div class="badge" id="scanBadge">Last scan: —</div></div></header>
<section class="card" style="margin-top:12px"><div class="small">WI-FI ADAPTERS — CHOOSE WHICH ADAPTERS TO USE</div><div id="adapterList" style="margin-top:8px">Loading adapters…</div><div class="controls"><button id="selectAllAdaptersBtn">USE ALL</button><button id="selectNoneAdaptersBtn">USE NONE</button><button id="applyAdaptersBtn">APPLY ADAPTERS</button><button id="refreshAdaptersBtn">REFRESH ADAPTERS</button><span class="small" id="adapterStatus"></span></div><div class="small">Checked adapters are scanned. Unchecked adapters are ignored. Your selection is saved on this computer.</div></section>
<section class="card" style="margin-top:12px"><div class="small">BAND FILTER — SHOW ALL BANDS OR ONE BAND</div><div class="controls"><button id="bandAllBtn" class="active">ALL</button><button id="band24Btn">2.4 GHz</button><button id="band5Btn">5 GHz</button><button id="band6Btn">6 GHz</button><span class="small" id="bandCounts">2.4: 0 • 5: 0 • 6: 0</span></div><div class="small">Band buttons filter the display. The operating system controls the actual Wi-Fi scan. The MAC log records every BSSID returned by the system scan.</div></section>
<section class="card hero"><div class="small">STRONGEST ACCESS POINT</div><div class="heroMac" id="strongMac">—</div><div class="heroMeta"><span id="strongSsid">SSID: —</span><span id="strongRssi">Signal: —</span><span id="strongFreq">Frequency: —</span><span id="strongBand">Band: —</span></div></section>
<section class="grid"><div class="card"><div class="small">TOP 5 STRONGEST ACCESS POINTS</div><div style="overflow:auto"><table><thead><tr><th>#</th><th>MAC/BSSID</th><th>SSID</th><th>RSSI</th><th>MHz</th><th>Ch</th></tr></thead><tbody id="rows"><tr><td colspan="6">Waiting for first scan…</td></tr></tbody></table></div></div><div class="card"><div class="small">CURRENT TOP 5 SIGNALS</div><div class="controls"><button id="lineBtn" class="active">LINE</button><button id="barBtn">BAR</button></div><canvas id="currentChart"></canvas></div></section>
<section class="card" style="margin-top:12px"><div class="small">SIGNAL HISTORY — CURRENT TOP 5 MACs</div><canvas id="historyChart"></canvas></section>
<section class="card" style="margin-top:12px"><div class="small">STATUS / LOG</div><div class="controls"><button id="shareLogBtn">SHARE / EMAIL MAC LOG</button><a class="actionLink" href="/log" download="all_found_macs_v4_1.txt">DOWNLOAD MAC LOG</a><button id="openFolderBtn">OPEN LOG FOLDER</button><button id="stopBtn" class="stop">STOP ANALYZER</button><span class="small" id="logCount">Logged MACs: 0</span></div><div id="error" class="error"></div><div class="small">Dashboard refreshes every second. Actual scans occur about every 5 seconds and may be throttled by Windows or NetworkManager.</div></section>
</div><script>
const COLORS=["#36d9ff","#43e18b","#ffd047","#ff9851","#b28aff"],$=id=>document.getElementById(id);let DATA={aps:[],history:{},error:"",last_scan:""},LAST_RENDER_KEY="",CHART_MODE=localStorage.getItem("wifiChartMode")||"line",BAND_FILTER=localStorage.getItem("wifiBandFilter")||"ALL";
function adapterChecks(){return Array.from(document.querySelectorAll(".adapterCheck"))}function renderAdapters(){const a=DATA.adapters||[];$("adapterList").innerHTML=a.length?a.map(x=>`<label style="display:block;padding:7px 0;border-bottom:1px solid #29445f"><input class="adapterCheck" type="checkbox" value="${safe(x.id)}" ${x.selected?"checked":""}> <b>${safe(x.name)}</b> — ${safe(x.description||"")} <span class="small">(${safe(x.state||"unknown")})</span></label>`).join(""):`<div class="small">No Wi-Fi adapters detected.</div>`;$("adapterStatus").textContent=`Selected: ${a.filter(x=>x.selected).length} / ${a.length}`}
async function loadAdapters(){try{const r=await fetch("/adapters",{cache:"no-store"}),n=await r.json();if(!r.ok)throw new Error(n.error||"Unable to list adapters");DATA.adapters=n.adapters||[];renderAdapters()}catch(e){$("adapterStatus").textContent=e.message}}
async function applyAdapters(){const selected=adapterChecks().filter(x=>x.checked).map(x=>x.value);try{const r=await fetch("/adapters",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({selected})}),n=await r.json();if(!r.ok)throw new Error(n.error||"Unable to save adapters");DATA.adapters=n.adapters||[];renderAdapters();$("adapterStatus").textContent=`Applied ${n.selected.length} adapter(s)`}catch(e){$("adapterStatus").textContent=e.message}}
function safe(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}function sigColor(r){if(r>=-50)return"#43e18b";if(r>=-65)return"#ffd047";if(r>=-75)return"#ff9851";return"#ff5d6c"}
function canvasSetup(id,height){const c=$(id),d=window.devicePixelRatio||1,w=Math.max(300,c.getBoundingClientRect().width),pw=Math.round(w*d),ph=Math.round(height*d);if(c.width!==pw||c.height!==ph){c.width=pw;c.height=ph;c.style.height=height+"px"}const ctx=c.getContext("2d");ctx.setTransform(d,0,0,d,0,0);ctx.fillStyle="#091727";ctx.fillRect(0,0,w,height);return[ctx,w,height]}
function drawGrid(ctx,w,h,L,R,T,B){[-100,-80,-60,-40,-20].forEach(v=>{const y=h-B-(v+100)/80*(h-T-B);ctx.strokeStyle="#29445f";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(L,y);ctx.lineTo(w-R,y);ctx.stroke();ctx.fillStyle="#9bb0c8";ctx.font="12px system-ui";ctx.textAlign="right";ctx.fillText(v+"",L-8,y+4)})}
function setChartMode(m){CHART_MODE=m;localStorage.setItem("wifiChartMode",m);$("lineBtn").classList.toggle("active",m==="line");$("barBtn").classList.toggle("active",m==="bar");requestAnimationFrame(render)}function setBandFilter(b){BAND_FILTER=b;localStorage.setItem("wifiBandFilter",b);[["bandAllBtn","ALL"],["band24Btn","2.4 GHz"],["band5Btn","5 GHz"],["band6Btn","6 GHz"]].forEach(([id,x])=>$(id).classList.toggle("active",x===b));requestAnimationFrame(render)}function filteredAps(){const a=DATA.aps||[];return BAND_FILTER==="ALL"?a:a.filter(x=>x.band===BAND_FILTER)}
function updateBandCounts(){const a=DATA.aps||[];$("bandCounts").textContent=`2.4: ${a.filter(x=>x.band==="2.4 GHz").length} • 5: ${a.filter(x=>x.band==="5 GHz").length} • 6: ${a.filter(x=>x.band==="6 GHz").length}`}
function drawCurrent(aps){const[ctx,w,h]=canvasSetup("currentChart",340),L=55,R=15,T=20,B=64;drawGrid(ctx,w,h,L,R,T,B);if(!aps.length)return;const usable=w-L-R,xFor=i=>L+(aps.length<=1?usable/2:(i/(aps.length-1))*usable),yFor=r=>h-B-(Math.max(-100,Math.min(-20,r))+100)/80*(h-T-B);if(CHART_MODE==="bar"){const gap=9,bw=Math.max(22,(w-L-R-gap*(aps.length+1))/aps.length);aps.forEach((a,i)=>{const y=yFor(a.rssi),x=L+gap+i*(bw+gap);ctx.fillStyle=COLORS[i%COLORS.length];ctx.fillRect(x,y,bw,h-B-y);ctx.fillStyle="#eff7ff";ctx.font="bold 12px ui-monospace,monospace";ctx.textAlign="center";ctx.fillText(a.rssi+" dBm",x+bw/2,y-7);ctx.save();ctx.translate(x+bw/2,h-B+15);ctx.rotate(-.45);ctx.textAlign="right";ctx.font="10px ui-monospace,monospace";ctx.fillText(a.mac,0,0);ctx.restore()})}else{ctx.strokeStyle="#36d9ff";ctx.lineWidth=3;ctx.beginPath();aps.forEach((a,i)=>{const x=xFor(i),y=yFor(a.rssi);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y)});ctx.stroke();aps.forEach((a,i)=>{const x=xFor(i),y=yFor(a.rssi);ctx.fillStyle=COLORS[i%COLORS.length];ctx.beginPath();ctx.arc(x,y,6,0,Math.PI*2);ctx.fill();ctx.fillStyle="#eff7ff";ctx.font="bold 12px ui-monospace,monospace";ctx.textAlign="center";ctx.fillText(a.rssi+" dBm",x,y-10);ctx.save();ctx.translate(x,h-B+18);ctx.rotate(-.45);ctx.textAlign="right";ctx.font="10px ui-monospace,monospace";ctx.fillText(a.mac,0,0);ctx.restore()})}}
function drawHistory(aps){const[ctx,w,h]=canvasSetup("historyChart",300),L=55,R=15,T=22,B=30;drawGrid(ctx,w,h,L,R,T,B);aps.forEach((a,i)=>{const arr=DATA.history[a.mac]||[];if(!arr.length)return;ctx.strokeStyle=COLORS[i%COLORS.length];ctx.lineWidth=3;ctx.beginPath();arr.forEach((p,j)=>{const x=L+(arr.length<=1?0:j/(arr.length-1))*(w-L-R),s=Math.max(-100,Math.min(-20,p.rssi)),y=h-B-(s+100)/80*(h-T-B);j===0?ctx.moveTo(x,y):ctx.lineTo(x,y)});ctx.stroke();ctx.fillStyle=COLORS[i%COLORS.length];ctx.font="bold 11px ui-monospace,monospace";ctx.textAlign="left";ctx.fillText((i+1)+": "+a.mac,L+5,T+14*i)})}
function render(){updateBandCounts();renderAdapters();const af=filteredAps(),aps=af.slice(0,5),f=aps[0];$("strongMac").textContent=f?.mac||"—";$("strongSsid").textContent="SSID: "+(f?.ssid||"—");$("strongRssi").textContent="Signal: "+(f?f.rssi+" dBm":"—");$("strongFreq").textContent="Frequency: "+(f&&f.frequency?f.frequency+" MHz":"—");$("strongBand").textContent="Band: "+(f?.band||"—");$("rows").innerHTML=aps.length?aps.map((a,i)=>`<tr><td>${i+1}</td><td class="mac">${safe(a.mac)}</td><td>${safe(a.ssid)}</td><td class="sig" style="color:${sigColor(a.rssi)}">${a.rssi} dBm</td><td>${a.frequency||"?"}</td><td>${a.channel}</td></tr>`).join(""):`<tr><td colspan="6">No AP data in this band.</td></tr>`;$("platformBadge").textContent=(DATA.platform||"Desktop")+" • "+(DATA.backend||"");$("statusBadge").textContent=DATA.error?"Scan error":"Running • total: "+(DATA.aps||[]).length+" • showing "+af.length+" • "+BAND_FILTER;$("statusBadge").className="badge "+(DATA.error?"bad":"ok");$("scanBadge").textContent="Last scan: "+(DATA.last_scan||"—");$("error").textContent=DATA.error||"";$("logCount").textContent="Logged MACs: "+(DATA.logged_macs||0);drawCurrent(aps);drawHistory(aps)}
async function update(){try{const r=await fetch("/api",{cache:"no-store"}),n=await r.json();if(!r.ok)throw new Error(n.error||"API error");DATA=n;const aps=filteredAps().slice(0,5),tail=aps.map(a=>{const h=(DATA.history&&DATA.history[a.mac])||[],last=h.length?h[h.length-1]:null;return[a.mac,a.rssi,h.length,last?last.rssi:null]});const key=JSON.stringify([DATA.last_scan,DATA.error,aps,tail,BAND_FILTER]);if(key!==LAST_RENDER_KEY){LAST_RENDER_KEY=key;requestAnimationFrame(render)}}catch(e){$("statusBadge").textContent="Dashboard error";$("statusBadge").className="badge bad";$("error").textContent=e.message}}
$("lineBtn").onclick=()=>setChartMode("line");$("barBtn").onclick=()=>setChartMode("bar");$("bandAllBtn").onclick=()=>setBandFilter("ALL");$("band24Btn").onclick=()=>setBandFilter("2.4 GHz");$("band5Btn").onclick=()=>setBandFilter("5 GHz");$("band6Btn").onclick=()=>setBandFilter("6 GHz");setChartMode(CHART_MODE);setBandFilter(BAND_FILTER);
$("selectAllAdaptersBtn").onclick=()=>adapterChecks().forEach(x=>x.checked=true);$("selectNoneAdaptersBtn").onclick=()=>adapterChecks().forEach(x=>x.checked=false);$("applyAdaptersBtn").onclick=applyAdapters;$("refreshAdaptersBtn").onclick=loadAdapters;loadAdapters();
$("shareLogBtn").onclick=async()=>{try{const r=await fetch("/log",{cache:"no-store"});if(!r.ok)throw new Error("No MAC log is available yet.");const blob=await r.blob(),file=new File([blob],"all_found_macs_v4_1.txt",{type:"text/plain"});if(navigator.share&&(!navigator.canShare||navigator.canShare({files:[file]}))){await navigator.share({title:"Wi-Fi Analyzer MAC Log",text:"Wi-Fi Analyzer v4.1 MAC/BSSID log",files:[file]})}else{const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}}catch(e){$("error").textContent=e.message}};
$("openFolderBtn").onclick=async()=>{try{await fetch("/open-folder",{method:"POST"})}catch(e){$("error").textContent=e.message}};$("stopBtn").onclick=async()=>{if(!confirm("Stop Wi-Fi Analyzer?"))return;try{await fetch("/shutdown",{method:"POST"});document.body.innerHTML="<div style='font-family:system-ui;padding:30px'><h2>Wi-Fi Analyzer stopped.</h2><p>You can close this tab.</p></div>"}catch(e){}};window.addEventListener("resize",()=>requestAnimationFrame(render));update();setInterval(update,1000);
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _raw(self, raw, content_type="text/plain; charset=utf-8", status=200, disposition=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        if disposition:
            self.send_header("Content-Disposition", disposition)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def send_json(self, obj, status=200):
        self._raw(json.dumps(obj).encode("utf-8"), "application/json", status)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self._raw(HTML.encode("utf-8"), "text/html; charset=utf-8")
            return
        if path == "/api":
            with state_lock:
                aps_copy = list(latest_aps)
                top_macs = [a["mac"] for a in aps_copy[:TOP_COUNT]]
                hist_copy = {mac: list(history.get(mac, [])) for mac in top_macs}
                payload = {
                    "aps": aps_copy, "history": hist_copy, "error": last_error,
                    "last_scan": last_scan_time, "logged_macs": len(logged_macs),
                    "platform": platform.system(), "backend": backend_name,
                    "adapters": [dict(a) for a in adapter_inventory],
                }
            self.send_json(payload)
            return
        if path == "/adapters":
            try:
                adapters = adapter_snapshot()
                self.send_json({"adapters": adapters, "selected": sorted(selected_adapters)})
            except Exception as exc:
                self.send_json({"error": str(exc)}, 500)
            return
        if path == "/log":
            raw = ALL_MAC_LOG.read_bytes() if ALL_MAC_LOG.exists() else b"No MAC/BSSID entries have been logged yet.\n"
            self._raw(raw, disposition='attachment; filename="all_found_macs_v4_1.txt"')
            return
        self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        global running
        path = urlparse(self.path).path
        if path == "/adapters":
            try:
                length = int(self.headers.get("Content-Length", "0") or "0")
                raw = self.rfile.read(length) if length else b"{}"
                body = json.loads(raw.decode("utf-8"))
                selected = body.get("selected", [])
                if not isinstance(selected, list):
                    raise ValueError("selected must be a list")
                set_selected_adapters(selected)
                self.send_json({"ok": True, "selected": sorted(selected_adapters), "adapters": adapter_snapshot()})
            except Exception as exc:
                self.send_json({"error": str(exc)}, 400)
            return
        if path == "/open-folder":
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            try:
                if IS_WINDOWS:
                    os.startfile(str(DATA_DIR))
                else:
                    subprocess.Popen(["xdg-open", str(DATA_DIR)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.send_json({"ok": True})
            except Exception as exc:
                self.send_json({"error": str(exc)}, 500)
            return
        if path == "/shutdown":
            self.send_json({"ok": True})
            running = False
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        self.send_json({"error": "Not found"}, 404)


def shutdown_handler(signum, frame):
    global running
    running = False
    raise KeyboardInterrupt


def open_dashboard(delay=1.5):
    time.sleep(delay)
    try:
        webbrowser.open(f"http://{HOST}:{PORT}")
    except Exception:
        pass


def main():
    global running
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    load_logged_macs()
    try:
        signal.signal(signal.SIGINT, shutdown_handler)
        signal.signal(signal.SIGTERM, shutdown_handler)
    except Exception:
        pass

    if not (IS_WINDOWS or IS_LINUX):
        raise SystemExit(f"Wi-Fi Analyzer v4.1 supports Windows and Linux/Debian. Detected: {platform.system()}")

    try:
        refresh_adapter_inventory()
    except Exception as exc:
        print(f"Adapter discovery warning: {exc}", flush=True)

    scanner = threading.Thread(target=scanner_loop, daemon=True)
    scanner.start()
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:
        open_dashboard(0)
        return 0

    print("=" * 78)
    print("WI-FI ANALYZER v4.1 DESKTOP")
    print("=" * 78)
    print(f"Platform: {platform.system()}   Backend: {backend_name}")
    print(f"Dashboard: http://{HOST}:{PORT}")
    print(f"MAC/BSSID log: {ALL_MAC_LOG}")
    print("=" * 78, flush=True)
    threading.Thread(target=open_dashboard, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        running = False
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
