# WiFi Analyzer Launcher

A tiny Android launcher app for the existing Termux/Python WiFi analyzer.

When its icon is tapped it:
1. uses Termux RUN_COMMAND to start `~/wifi-analyzer/android_wifi_analyzer_v2.py` if it is not already running;
2. waits 3 seconds;
3. opens `http://127.0.0.1:8080` in the default browser.

## Required on the tablet
- Termux installed.
- The Python analyzer at `~/wifi-analyzer/android_wifi_analyzer_v2.py`.
- `allow-external-apps=true` in `~/.termux/termux.properties`.
- The launcher app's `Run commands in Termux environment` permission granted.

See `TERMUX-ONE-TIME-SETUP.txt`.

## Build
Open the project in Android Studio and choose **Build > Build APK(s)**.
A GitHub Actions workflow is also included.
