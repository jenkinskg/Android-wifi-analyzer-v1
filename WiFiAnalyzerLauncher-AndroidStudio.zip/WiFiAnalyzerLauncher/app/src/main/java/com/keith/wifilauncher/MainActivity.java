package com.keith.wifilauncher;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_TERMUX = 41;
    private static final String RUN_PERMISSION = "com.termux.permission.RUN_COMMAND";
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showStartingScreen();

        if (!isTermuxInstalled()) {
            Toast.makeText(this, "Termux is not installed", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{RUN_PERMISSION}, REQ_TERMUX);
        } else {
            launchAnalyzer();
        }
    }

    private void showStartingScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);
        root.setBackgroundColor(Color.rgb(7,17,29));

        TextView title = new TextView(this);
        title.setText("WiFi Analyzer");
        title.setTextColor(Color.rgb(53,216,255));
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView status = new TextView(this);
        status.setText("Starting analyzer…");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setPadding(0,24,0,0);
        status.setGravity(Gravity.CENTER);
        root.addView(status);

        setContentView(root);
    }

    private boolean isTermuxInstalled() {
        try {
            getPackageManager().getPackageInfo("com.termux", 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_TERMUX && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchAnalyzer();
        } else {
            Toast.makeText(this, "Allow 'Run commands in Termux environment' for this app", Toast.LENGTH_LONG).show();
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) {}
        }
    }

    private void launchAnalyzer() {
        String command = "pgrep -f android_wifi_analyzer_v2.py >/dev/null 2>&1 || " +
                "nohup /data/data/com.termux/files/usr/bin/python " +
                "/data/data/com.termux/files/home/wifi-analyzer/android_wifi_analyzer_v2.py " +
                "> /data/data/com.termux/files/home/wifi-analyzer/icon-start.log 2>&1 &";

        try {
            Intent intent = new Intent();
            intent.setClassName("com.termux", "com.termux.app.RunCommandService");
            intent.setAction("com.termux.RUN_COMMAND");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", command});
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            startService(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not start Termux command: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        handler.postDelayed(() -> {
            try {
                Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("http://127.0.0.1:8080"));
                startActivity(browser);
            } catch (Exception e) {
                Toast.makeText(this, "Open http://127.0.0.1:8080 in your browser", Toast.LENGTH_LONG).show();
            }
            finish();
        }, 3000);
    }
}
