# Standalone WiFi Analyzer for Android

This version does **not** require Termux, Python, or a browser.

Features:
- normal Android app icon;
- built-in Wi-Fi scanning;
- Top 4 / Top 5 toggle;
- full BSSID/MAC, SSID, RSSI, frequency, channel and band;
- current signal bar graph;
- signal history graph;
- Start/Stop control;
- keeps the last good scan visible when Android throttles or delays a scan.

## Permissions
The app requests Wi-Fi and location-related permissions required by Android for Wi-Fi scan results. Device Location must also be enabled for `WifiManager` scanning on many Android versions.

## Android scan throttling
Android may limit how often apps can request active Wi-Fi scans. The app never blanks the display when a new scan is throttled; it keeps showing the last good results.

## Build APK in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose **Build > Build APK(s)**.
4. Install `app/build/outputs/apk/debug/app-debug.apk` on the second Android device.

A GitHub Actions workflow is included under `.github/workflows/build-apk.yml` if you prefer a cloud build.
