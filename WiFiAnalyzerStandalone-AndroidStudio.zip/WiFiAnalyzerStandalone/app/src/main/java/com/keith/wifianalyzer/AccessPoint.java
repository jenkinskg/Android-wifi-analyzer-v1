package com.keith.wifianalyzer;

class AccessPoint {
    final String bssid;
    final String ssid;
    final int rssi;
    final int frequency;
    final int channel;
    final String band;

    AccessPoint(String bssid, String ssid, int rssi, int frequency) {
        this.bssid = bssid == null ? "" : bssid.toUpperCase();
        this.ssid = (ssid == null || ssid.isEmpty()) ? "<hidden>" : ssid;
        this.rssi = rssi;
        this.frequency = frequency;
        this.channel = channelFromFrequency(frequency);
        this.band = bandFromFrequency(frequency);
    }

    static int channelFromFrequency(int f) {
        if (f == 2484) return 14;
        if (f >= 2412 && f <= 2472) return (f - 2407) / 5;
        if (f >= 5000 && f <= 5895) return (f - 5000) / 5;
        if (f >= 5955 && f <= 7115) return (f - 5950) / 5;
        return 0;
    }

    static String bandFromFrequency(int f) {
        if (f >= 2400 && f < 2500) return "2.4 GHz";
        if (f >= 4900 && f < 5925) return "5 GHz";
        if (f >= 5925 && f <= 7125) return "6 GHz";
        return "Other";
    }
}
