package com.keith.wifianalyzer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class CurrentBarsView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<AccessPoint> aps = new ArrayList<>();
    private final int[] colors = {
            Color.rgb(53,216,255), Color.rgb(67,225,139), Color.rgb(255,208,71),
            Color.rgb(255,152,81), Color.rgb(178,138,255)
    };

    CurrentBarsView(Context c) { super(c); setMinimumHeight(dp(260)); }
    void setAccessPoints(List<AccessPoint> value) { aps = new ArrayList<>(value); invalidate(); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(Color.rgb(9,23,39));
        int w=getWidth(), h=getHeight();
        float L=56, R=14, T=20, B=42;
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(dp(11));
        for (int v=-100; v<=-20; v+=20) {
            float y=h-B-(v+100)/80f*(h-T-B);
            p.setColor(Color.rgb(41,68,95)); p.setStrokeWidth(1); c.drawLine(L,y,w-R,y,p);
            p.setColor(Color.rgb(156,177,200)); p.setTextAlign(Paint.Align.RIGHT); c.drawText(String.valueOf(v),L-7,y+4,p);
        }
        if (aps.isEmpty()) return;
        float gap=8;
        float bw=Math.max(24,(w-L-R-gap*(aps.size()+1))/aps.size());
        for(int i=0;i<aps.size();i++){
            AccessPoint a=aps.get(i);
            int s=Math.max(-100,Math.min(-20,a.rssi));
            float y=h-B-(s+100)/80f*(h-T-B);
            float x=L+gap+i*(bw+gap);
            p.setColor(colors[i%colors.length]); c.drawRect(x,y,x+bw,h-B,p);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(11));
            c.drawText(a.rssi+" dBm",x+bw/2,y-7,p);
            p.setTextSize(dp(9)); c.save(); c.rotate(-28,x+bw/2,h-B+12); c.drawText(a.bssid,x+bw/2,h-B+12,p); c.restore();
        }
    }
}

class SignalHistoryView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<AccessPoint> aps = new ArrayList<>();
    private final Map<String, ArrayList<Integer>> history = new HashMap<>();
    private final int[] colors = {
            Color.rgb(53,216,255), Color.rgb(67,225,139), Color.rgb(255,208,71),
            Color.rgb(255,152,81), Color.rgb(178,138,255)
    };
    private static final int MAX_POINTS=60;

    SignalHistoryView(Context c) { super(c); setMinimumHeight(dp(260)); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    void addSample(List<AccessPoint> value) {
        aps = new ArrayList<>(value);
        for(AccessPoint a:value){
            ArrayList<Integer> list=history.computeIfAbsent(a.bssid,k->new ArrayList<>());
            list.add(a.rssi);
            while(list.size()>MAX_POINTS) list.remove(0);
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); c.drawColor(Color.rgb(9,23,39));
        int w=getWidth(), h=getHeight(); float L=56,R=14,T=22,B=26;
        p.setTextSize(dp(11)); p.setTypeface(Typeface.DEFAULT);
        for(int v=-100;v<=-20;v+=20){
            float y=h-B-(v+100)/80f*(h-T-B);
            p.setColor(Color.rgb(41,68,95)); p.setStrokeWidth(1); c.drawLine(L,y,w-R,y,p);
            p.setColor(Color.rgb(156,177,200)); p.setTextAlign(Paint.Align.RIGHT); c.drawText(String.valueOf(v),L-7,y+4,p);
        }
        for(int i=0;i<aps.size();i++){
            AccessPoint a=aps.get(i); ArrayList<Integer> list=history.get(a.bssid); if(list==null||list.isEmpty())continue;
            p.setColor(colors[i%colors.length]); p.setStrokeWidth(dp(3)); p.setStyle(Paint.Style.STROKE);
            android.graphics.Path path=new android.graphics.Path();
            for(int j=0;j<list.size();j++){
                float x=L+(list.size()==1?0:j/(float)(list.size()-1))*(w-L-R);
                int s=Math.max(-100,Math.min(-20,list.get(j)));
                float y=h-B-(s+100)/80f*(h-T-B);
                if(j==0)path.moveTo(x,y);else path.lineTo(x,y);
            }
            c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(10)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.LEFT);
            c.drawText((i+1)+": "+a.bssid,L+5,T+dp(12)*i,p);
        }
    }
}
