package com.keith.wifianalyzer;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_PERMS=10;
    private static final long SCAN_INTERVAL_MS=5000;

    private WifiManager wifi;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean running=true;
    private int topCount=5;
    private boolean receiverRegistered=false;
    private List<AccessPoint> lastGood=new ArrayList<>();

    private TextView status, strongest, strongestMeta, rows;
    private Button startStop, topToggle;
    private CurrentBarsView bars;
    private SignalHistoryView history;

    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context, Intent intent){
            boolean updated=intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED,false);
            updateResults(updated ? "new scan" : "cached scan");
        }
    };

    private final Runnable scanLoop=new Runnable(){
        @Override public void run(){
            if(!running) return;
            try{
                boolean requested=wifi.startScan();
                if(!requested) updateResults("scan throttled — showing last results");
            }catch(SecurityException e){
                status.setText("Permission required: "+e.getMessage());
            }
            handler.postDelayed(this,SCAN_INTERVAL_MS);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        buildUi();
        requestNeededPermissions();
    }

    @Override protected void onResume(){
        super.onResume();
        registerScanReceiver();
        if(hasPermissions()) startScanning();
    }

    @Override protected void onPause(){
        super.onPause();
        // Keep the last display in memory. Android itself may limit background Wi-Fi scans.
        handler.removeCallbacks(scanLoop);
    }

    @Override protected void onDestroy(){
        super.onDestroy();
        handler.removeCallbacks(scanLoop);
        if(receiverRegistered){ unregisterReceiver(receiver); receiverRegistered=false; }
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12),dp(12),dp(12),dp(24));
        root.setBackgroundColor(Color.rgb(7,17,29));
        scroll.addView(root);

        TextView title=text("WiFi Analyzer",30,Color.rgb(53,216,255),true); root.addView(title);
        TextView subtitle=text("Standalone Android scanner • built-in Wi-Fi",14,Color.rgb(156,177,200),false); root.addView(subtitle);

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,dp(12),0,dp(8));
        startStop=new Button(this); startStop.setText("STOP"); startStop.setOnClickListener(v->{ running=!running; startStop.setText(running?"STOP":"START"); if(running) startScanning(); else {handler.removeCallbacks(scanLoop); status.setText("Stopped — last scan remains visible");} }); buttons.addView(startStop);
        topToggle=new Button(this); topToggle.setText("TOP 5"); topToggle.setOnClickListener(v->{ topCount=topCount==5?4:5; topToggle.setText("TOP "+topCount); render(lastGood,"display changed"); }); buttons.addView(topToggle);
        root.addView(buttons);

        status=text("Starting…",14,Color.rgb(67,225,139),true); root.addView(status);

        TextView lab=text("STRONGEST ACCESS POINT",12,Color.rgb(156,177,200),true); lab.setPadding(0,dp(14),0,0); root.addView(lab);
        strongest=text("—",28,Color.rgb(53,216,255),true); root.addView(strongest);
        strongest.setHorizontallyScrolling(false);
        strongestMeta=text("SSID: —   Signal: —   Frequency: —",15,Color.WHITE,false); root.addView(strongestMeta);

        TextView listLab=text("TOP ACCESS POINTS",12,Color.rgb(156,177,200),true); listLab.setPadding(0,dp(18),0,dp(4)); root.addView(listLab);
        rows=text("Waiting for scan…",14,Color.WHITE,false); rows.setTypeface(android.graphics.Typeface.MONOSPACE); root.addView(rows);

        TextView barsLab=text("CURRENT SIGNAL STRENGTH",12,Color.rgb(156,177,200),true); barsLab.setPadding(0,dp(18),0,dp(4)); root.addView(barsLab);
        bars=new CurrentBarsView(this); root.addView(bars,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(300)));

        TextView histLab=text("SIGNAL HISTORY",12,Color.rgb(156,177,200),true); histLab.setPadding(0,dp(18),0,dp(4)); root.addView(histLab);
        history=new SignalHistoryView(this); root.addView(history,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(300)));

        TextView note=text("Android may throttle repeated Wi-Fi scans. The app keeps the last good scan visible instead of flashing blank.",12,Color.rgb(156,177,200),false); note.setPadding(0,dp(12),0,0); root.addView(note);
        setContentView(scroll);
    }

    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.START); t.setPadding(0,dp(3),0,dp(3));
        if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return t;
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private void requestNeededPermissions(){
        ArrayList<String> need=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)!=PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        if(!need.isEmpty()) requestPermissions(need.toArray(new String[0]),REQ_PERMS);
    }

    private boolean hasPermissions(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return false;
        return Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)==PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_PERMS){
            if(hasPermissions()) startScanning();
            else status.setText("Wi-Fi scan permissions were not granted");
        }
    }

    private void registerScanReceiver(){
        if(receiverRegistered)return;
        IntentFilter f=new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        receiverRegistered=true;
    }

    private void startScanning(){
        if(!hasPermissions()){ requestNeededPermissions(); return; }
        running=true; startStop.setText("STOP");
        handler.removeCallbacks(scanLoop); updateResults("using available results"); handler.post(scanLoop);
    }

    private void updateResults(String source){
        if(!hasPermissions())return;
        try{
            List<ScanResult> raw=wifi.getScanResults();
            if(raw==null || raw.isEmpty()){
                if(lastGood.isEmpty()) status.setText("No Wi-Fi scan results yet. Make sure Location is ON.");
                else status.setText("No new results — keeping last good scan");
                return;
            }
            Map<String,AccessPoint> unique=new LinkedHashMap<>();
            for(ScanResult r:raw){
                if(r.BSSID==null || r.BSSID.isEmpty())continue;
                AccessPoint a=new AccessPoint(r.BSSID,r.SSID,r.level,r.frequency);
                AccessPoint old=unique.get(a.bssid);
                if(old==null || a.rssi>old.rssi)unique.put(a.bssid,a);
            }
            ArrayList<AccessPoint> list=new ArrayList<>(unique.values());
            Collections.sort(list,Comparator.comparingInt((AccessPoint a)->a.rssi).reversed());
            if(!list.isEmpty()) lastGood=list;
            render(lastGood,source);
        }catch(SecurityException e){
            status.setText("Permission/location error: "+e.getMessage());
        }
    }

    private void render(List<AccessPoint> all,String source){
        if(all==null || all.isEmpty())return;
        int n=Math.min(topCount,all.size()); List<AccessPoint> top=new ArrayList<>(all.subList(0,n));
        AccessPoint first=top.get(0);
        strongest.setText(first.bssid);
        strongestMeta.setText("SSID: "+first.ssid+"   Signal: "+first.rssi+" dBm   Frequency: "+first.frequency+" MHz   "+first.band);
        StringBuilder sb=new StringBuilder();
        sb.append(String.format(Locale.US,"%-2s %-18s %8s %8s %4s  %s\n","#","BSSID / MAC","RSSI","MHz","CH","SSID"));
        for(int i=0;i<top.size();i++){
            AccessPoint a=top.get(i);
            sb.append(String.format(Locale.US,"%-2d %-18s %4d dBm %5d %4d  %s\n",i+1,a.bssid,a.rssi,a.frequency,a.channel,a.ssid));
        }
        rows.setText(sb.toString());
        bars.setAccessPoints(top); history.addSample(top);
        String ts=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());
        status.setText("Running • APs seen: "+all.size()+" • "+source+" • "+ts);
    }
}
