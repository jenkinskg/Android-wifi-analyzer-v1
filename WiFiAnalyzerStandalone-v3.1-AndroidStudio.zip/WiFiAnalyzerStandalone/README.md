# WiFi Analyzer v3.1 - Standalone Android

Native Android Wi-Fi analyzer. No Termux or Python required.

## v3.1 changes
- New BAND button cycles: ALL -> 2.4 GHz -> 5 GHz -> 6 GHz -> ALL.
- Status shows AP counts for 2.4, 5, and 6 GHz so you can immediately see what Android actually returned.
- Band selection filters the display and graphs only. Android still uses the system Wi-Fi scanner and returns all supported/visible bands.
- Logs every unique discovered MAC/BSSID from ALL bands to `all_found_macs_v3.txt`, regardless of the display filter.
- Current-signal graph switches between LINE and BAR. LINE is the default.
- Signal-history graph remains a line graph.
- EMAIL MAC LOG opens Android's share sheet.
- Shows Top 4 / Top 5, SSID, BSSID, RSSI, frequency, channel, and band.

Android may throttle repeated active Wi-Fi scans. Location/Wi-Fi scanning services may need to be enabled for BSSID scan results. 6 GHz results require 6 GHz-capable device hardware and nearby 6 GHz APs.

Package id: com.keith.wifianalyzer.v3
Version: 3.1
