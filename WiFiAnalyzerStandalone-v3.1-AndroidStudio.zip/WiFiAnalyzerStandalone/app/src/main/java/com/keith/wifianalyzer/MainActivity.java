package com.keith.wifianalyzer;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_PERMS=10;
    private static final long SCAN_INTERVAL_MS=5000;

    private WifiManager wifi;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean running=true;
    private int topCount=5;
    private boolean lineGraph=true;
    private String bandFilter="ALL";
    private boolean receiverRegistered=false;
    private List<AccessPoint> lastGood=new ArrayList<>();

    private TextView status, strongest, strongestMeta, rows, logStatus;
    private Button startStop, topToggle, graphToggle, emailLog, bandToggle;
    private CurrentBarsView currentGraph;
    private SignalHistoryView history;

    private File macLogFile;
    private final Set<String> loggedMacs=new HashSet<>();

    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context, Intent intent){
            boolean updated=intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED,false);
            updateResults(updated ? "new scan" : "cached scan");
        }
    };

    private final Runnable scanLoop=new Runnable(){
        @Override public void run(){
            if(!running) return;
            try{
                boolean requested=wifi.startScan();
                if(!requested) updateResults("scan throttled — showing last results");
            }catch(SecurityException e){
                status.setText("Permission required: "+e.getMessage());
            }
            handler.postDelayed(this,SCAN_INTERVAL_MS);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        initMacLog();
        buildUi();
        requestNeededPermissions();
    }

    @Override protected void onResume(){
        super.onResume();
        registerScanReceiver();
        if(hasPermissions()) startScanning();
    }

    @Override protected void onPause(){
        super.onPause();
        handler.removeCallbacks(scanLoop);
    }

    @Override protected void onDestroy(){
        super.onDestroy();
        handler.removeCallbacks(scanLoop);
        if(receiverRegistered){ unregisterReceiver(receiver); receiverRegistered=false; }
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12),dp(12),dp(12),dp(24));
        root.setBackgroundColor(Color.rgb(7,17,29));
        scroll.addView(root);

        TextView title=text("WiFi Analyzer v3.1",30,Color.rgb(53,216,255),true); root.addView(title);
        TextView subtitle=text("Standalone Android scanner • 2.4/5/6 GHz display filter • line/bar graphs • MAC logging",14,Color.rgb(156,177,200),false); root.addView(subtitle);

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,dp(12),0,dp(8));
        startStop=new Button(this); startStop.setText("STOP");
        startStop.setOnClickListener(v->{
            running=!running; startStop.setText(running?"STOP":"START");
            if(running) startScanning(); else { handler.removeCallbacks(scanLoop); status.setText("Stopped — last scan remains visible"); }
        });
        buttons.addView(startStop);

        topToggle=new Button(this); topToggle.setText("TOP 5");
        topToggle.setOnClickListener(v->{ topCount=topCount==5?4:5; topToggle.setText("TOP "+topCount); render(lastGood,"display changed"); });
        buttons.addView(topToggle);
        root.addView(buttons);

        LinearLayout bandButtons=new LinearLayout(this); bandButtons.setOrientation(LinearLayout.HORIZONTAL); bandButtons.setPadding(0,0,0,dp(8));
        bandToggle=new Button(this); bandToggle.setText("BAND: ALL");
        bandToggle.setOnClickListener(v->{
            if("ALL".equals(bandFilter)) bandFilter="2.4 GHz";
            else if("2.4 GHz".equals(bandFilter)) bandFilter="5 GHz";
            else if("5 GHz".equals(bandFilter)) bandFilter="6 GHz";
            else bandFilter="ALL";
            bandToggle.setText("BAND: "+bandFilter);
            render(lastGood,"band filter changed");
        });
        bandButtons.addView(bandToggle);
        TextView bandHint=text("Tap to cycle ALL → 2.4 → 5 → 6 GHz",12,Color.rgb(156,177,200),false);
        bandHint.setPadding(dp(8),dp(10),0,0); bandButtons.addView(bandHint);
        root.addView(bandButtons);

        LinearLayout graphButtons=new LinearLayout(this); graphButtons.setOrientation(LinearLayout.HORIZONTAL); graphButtons.setPadding(0,0,0,dp(8));
        graphToggle=new Button(this); graphToggle.setText("GRAPH: LINE");
        graphToggle.setOnClickListener(v->{
            lineGraph=!lineGraph;
            graphToggle.setText(lineGraph?"GRAPH: LINE":"GRAPH: BAR");
            currentGraph.setLineMode(lineGraph);
        });
        graphButtons.addView(graphToggle);

        emailLog=new Button(this); emailLog.setText("EMAIL MAC LOG"); emailLog.setOnClickListener(v->shareMacLog()); graphButtons.addView(emailLog);
        root.addView(graphButtons);

        status=text("Starting…",14,Color.rgb(67,225,139),true); root.addView(status);
        logStatus=text(logStatusText(),12,Color.rgb(156,177,200),false); root.addView(logStatus);

        TextView lab=text("STRONGEST ACCESS POINT",12,Color.rgb(156,177,200),true); lab.setPadding(0,dp(14),0,0); root.addView(lab);
        strongest=text("—",28,Color.rgb(53,216,255),true); root.addView(strongest);
        strongest.setHorizontallyScrolling(false);
        strongestMeta=text("SSID: —   Signal: —   Frequency: —",15,Color.WHITE,false); root.addView(strongestMeta);

        TextView listLab=text("TOP ACCESS POINTS",12,Color.rgb(156,177,200),true); listLab.setPadding(0,dp(18),0,dp(4)); root.addView(listLab);
        rows=text("Waiting for scan…",14,Color.WHITE,false); rows.setTypeface(android.graphics.Typeface.MONOSPACE); root.addView(rows);

        TextView graphLab=text("CURRENT SIGNAL STRENGTH — LINE/BAR SELECTABLE",12,Color.rgb(156,177,200),true); graphLab.setPadding(0,dp(18),0,dp(4)); root.addView(graphLab);
        currentGraph=new CurrentBarsView(this); currentGraph.setLineMode(true);
        root.addView(currentGraph,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(300)));

        TextView histLab=text("SIGNAL HISTORY",12,Color.rgb(156,177,200),true); histLab.setPadding(0,dp(18),0,dp(4)); root.addView(histLab);
        history=new SignalHistoryView(this); root.addView(history,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(300)));

        TextView note=text("Band selection filters what is displayed; Android still asks the system Wi-Fi scanner for every band the phone supports and can see. Every unique MAC/BSSID found on all bands is logged once. Tap EMAIL MAC LOG to attach it to Gmail or another mail app. Android may throttle repeated Wi-Fi scans.",12,Color.rgb(156,177,200),false); note.setPadding(0,dp(12),0,0); root.addView(note);
        setContentView(scroll);
    }

    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.START); t.setPadding(0,dp(3),0,dp(3));
        if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return t;
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private void requestNeededPermissions(){
        ArrayList<String> need=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)!=PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        if(!need.isEmpty()) requestPermissions(need.toArray(new String[0]),REQ_PERMS);
    }

    private boolean hasPermissions(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return false;
        return Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)==PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_PERMS){
            if(hasPermissions()) startScanning();
            else status.setText("Wi-Fi scan permissions were not granted");
        }
    }

    private void registerScanReceiver(){
        if(receiverRegistered)return;
        IntentFilter f=new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        receiverRegistered=true;
    }

    private void startScanning(){
        if(!hasPermissions()){ requestNeededPermissions(); return; }
        running=true; startStop.setText("STOP");
        handler.removeCallbacks(scanLoop); updateResults("using available results"); handler.post(scanLoop);
    }

    private void updateResults(String source){
        if(!hasPermissions())return;
        try{
            List<ScanResult> raw=wifi.getScanResults();
            if(raw==null || raw.isEmpty()){
                if(lastGood.isEmpty()) status.setText("No Wi-Fi scan results yet. Make sure Location is ON.");
                else status.setText("No new results — keeping last good scan");
                return;
            }
            Map<String,AccessPoint> unique=new LinkedHashMap<>();
            for(ScanResult r:raw){
                if(r.BSSID==null || r.BSSID.isEmpty())continue;
                AccessPoint a=new AccessPoint(r.BSSID,r.SSID,r.level,r.frequency);
                AccessPoint old=unique.get(a.bssid);
                if(old==null || a.rssi>old.rssi)unique.put(a.bssid,a);
            }
            ArrayList<AccessPoint> list=new ArrayList<>(unique.values());
            Collections.sort(list,Comparator.comparingInt((AccessPoint a)->a.rssi).reversed());
            logNewMacs(list);
            if(!list.isEmpty()) lastGood=list;
            render(lastGood,source);
        }catch(SecurityException e){
            status.setText("Permission/location error: "+e.getMessage());
        }
    }

    private boolean matchesBand(AccessPoint a){
        return "ALL".equals(bandFilter) || bandFilter.equals(a.band);
    }

    private List<AccessPoint> filterByBand(List<AccessPoint> all){
        ArrayList<AccessPoint> out=new ArrayList<>();
        if(all==null) return out;
        for(AccessPoint a:all) if(matchesBand(a)) out.add(a);
        return out;
    }

    private int countBand(List<AccessPoint> all,String band){
        int n=0; if(all==null) return 0;
        for(AccessPoint a:all) if(band.equals(a.band)) n++;
        return n;
    }

    private void render(List<AccessPoint> all,String source){
        if(all==null || all.isEmpty())return;
        List<AccessPoint> filtered=filterByBand(all);
        int c24=countBand(all,"2.4 GHz"), c5=countBand(all,"5 GHz"), c6=countBand(all,"6 GHz");
        String ts=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());

        if(filtered.isEmpty()){
            strongest.setText("NO APs IN "+bandFilter);
            strongestMeta.setText("No "+bandFilter+" access points are present in the current Android scan results.");
            rows.setText("No access points found for BAND: "+bandFilter+"\n\nAll-band counts: 2.4 GHz="+c24+"   5 GHz="+c5+"   6 GHz="+c6);
            currentGraph.setAccessPoints(new ArrayList<>());
            history.addSample(new ArrayList<>());
            status.setText("Running • total: "+all.size()+" • showing: 0 • BAND: "+bandFilter+" • 2.4="+c24+" 5="+c5+" 6="+c6+" • "+ts);
            logStatus.setText(logStatusText());
            return;
        }

        int n=Math.min(topCount,filtered.size()); List<AccessPoint> top=new ArrayList<>(filtered.subList(0,n));
        AccessPoint first=top.get(0);
        strongest.setText(first.bssid);
        strongestMeta.setText("SSID: "+first.ssid+"   Signal: "+first.rssi+" dBm   Frequency: "+first.frequency+" MHz   "+first.band);
        StringBuilder sb=new StringBuilder();
        sb.append(String.format(Locale.US,"%-2s %-18s %8s %8s %4s  %s\n","#","BSSID / MAC","RSSI","MHz","CH","SSID"));
        for(int i=0;i<top.size();i++){
            AccessPoint a=top.get(i);
            sb.append(String.format(Locale.US,"%-2d %-18s %4d dBm %5d %4d  %s\n",i+1,a.bssid,a.rssi,a.frequency,a.channel,a.ssid));
        }
        rows.setText(sb.toString());
        currentGraph.setAccessPoints(top); history.addSample(top);
        status.setText("Running • total: "+all.size()+" • showing: "+filtered.size()+" • BAND: "+bandFilter+" • 2.4="+c24+" 5="+c5+" 6="+c6+" • "+source+" • "+ts);
        logStatus.setText(logStatusText());
    }

    private void initMacLog(){
        File base=getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if(base==null) base=getFilesDir();
        File dir=new File(base,"WiFiAnalyzer");
        if(!dir.exists()) dir.mkdirs();
        macLogFile=new File(dir,"all_found_macs_v3.txt");
        loadLoggedMacs();
    }

    private void loadLoggedMacs(){
        loggedMacs.clear();
        if(macLogFile==null || !macLogFile.exists())return;
        try(BufferedReader br=new BufferedReader(new FileReader(macLogFile))){
            String line;
            while((line=br.readLine())!=null){
                if(!line.startsWith("AP\t"))continue;
                String[] p=line.split("\\t",-1);
                if(p.length>=3)loggedMacs.add(p[2].trim().toUpperCase(Locale.US));
            }
        }catch(IOException ignored){}
    }

    private String clean(String s){
        if(s==null)return "";
        return s.replace('\t',' ').replace('\n',' ').replace('\r',' ');
    }

    private void logNewMacs(List<AccessPoint> aps){
        if(macLogFile==null || aps==null || aps.isEmpty())return;
        ArrayList<AccessPoint> fresh=new ArrayList<>();
        for(AccessPoint a:aps) if(!loggedMacs.contains(a.bssid)) fresh.add(a);
        if(fresh.isEmpty())return;
        boolean newFile=!macLogFile.exists() || macLogFile.length()==0;
        String stamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z",Locale.US).format(new Date());
        try(FileWriter fw=new FileWriter(macLogFile,true)){
            if(newFile){
                fw.write("WiFi Analyzer v3.1 - All Found MAC/BSSID Log\n");
                fw.write("Each BSSID is recorded once, when first discovered.\n");
                fw.write("TYPE\tFIRST_SEEN\tMAC/BSSID\tSSID\tRSSI_DBM\tFREQUENCY_MHZ\tCHANNEL\tBAND\n");
            }
            for(AccessPoint a:fresh){
                fw.write("AP\t"+stamp+"\t"+a.bssid+"\t"+clean(a.ssid)+"\t"+a.rssi+"\t"+a.frequency+"\t"+a.channel+"\t"+a.band+"\n");
                loggedMacs.add(a.bssid);
            }
        }catch(IOException e){
            status.setText("MAC log write error: "+e.getMessage());
        }
    }

    private String logStatusText(){
        String path=macLogFile==null?"not available":macLogFile.getAbsolutePath();
        return "Logged unique MACs: "+loggedMacs.size()+" • "+path;
    }

    private void shareMacLog(){
        if(macLogFile==null || !macLogFile.exists() || macLogFile.length()==0){
            status.setText("No MAC log yet — wait for a Wi-Fi scan first.");
            return;
        }
        try{
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",macLogFile);
            Intent send=new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT,"WiFi Analyzer v3.1 MAC/BSSID Log");
            send.putExtra(Intent.EXTRA_TEXT,"Attached is the WiFi Analyzer v3.1 list of discovered MAC/BSSID addresses.");
            send.putExtra(Intent.EXTRA_STREAM,uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,"Email / share MAC log"));
        }catch(Exception e){
            status.setText("Unable to share MAC log: "+e.getMessage());
        }
    }
}
